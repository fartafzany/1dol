export {};
//# sourceMappingURL=initializeMultisig2.d.ts.map