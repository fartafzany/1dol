export {};
//# sourceMappingURL=internal.d.ts.map