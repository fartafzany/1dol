export declare enum AccountType {
    Uninitialized = 0,
    Mint = 1,
    Account = 2
}
export declare const ACCOUNT_TYPE_SIZE = 1;
//# sourceMappingURL=accountType.d.ts.map