export enum AccountType {
    Uninitialized,
    Mint,
    Account,
}
export const ACCOUNT_TYPE_SIZE = 1;
