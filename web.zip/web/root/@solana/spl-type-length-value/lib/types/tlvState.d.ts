/// <reference types="node" />
export type LengthSize = 1 | 2 | 4 | 8;
export type Discriminator = Uint8Array;
export declare class TlvState {
    private readonly tlvData;
    private readonly discriminatorSize;
    private readonly lengthSize;
    constructor(buffer: Buffer, discriminatorSize?: number, lengthSize?: LengthSize, offset?: number);
    /**
     * Get the raw tlv data
     *
     * @return the raw tlv data
     */
    get data(): Buffer;
    private readEntryLength;
    /**
     * Get a single entry from the tlv data. This function returns the first entry with the given type.
     *
     * @param type the type of the entry to get
     *
     * @return the entry from the tlv data or null
     */
    firstBytes(discriminator: Discriminator): Buffer | null;
    /**
     * Get a multiple entries from the tlv data. This function returns `count` or less entries with the given type.
     *
     * @param type the type of the entry to get
     * @param count the number of entries to get (0 for all entries)
     *
     * @return the entry from the tlv data or null
     */
    bytesRepeating(discriminator: Discriminator, count?: number): Buffer[];
    /**
     * Get all the discriminators from the tlv data. This function will return a type multiple times if it occurs multiple times in the tlv data.
     *
     * @return a list of the discriminators.
     */
    discriminators(): Buffer[];
}
//# sourceMappingURL=tlvState.d.ts.map