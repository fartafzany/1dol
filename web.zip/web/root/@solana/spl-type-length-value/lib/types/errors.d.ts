/** Base class for errors */
export declare abstract class TlvError extends Error {
    constructor(message?: string);
}
/** Thrown if the byte length of an tlv buffer doesn't match the expected size */
export declare class TlvInvalidAccountDataError extends TlvError {
    name: string;
}
//# sourceMappingURL=errors.d.ts.map