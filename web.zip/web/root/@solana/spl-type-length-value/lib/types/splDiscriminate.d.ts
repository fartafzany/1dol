export declare const splDiscriminate: (discriminator: string, length?: number) => Buffer;
//# sourceMappingURL=splDiscriminate.d.ts.map