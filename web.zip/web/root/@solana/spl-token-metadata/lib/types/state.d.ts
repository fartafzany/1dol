/// <reference types="node" />
import { PublicKey } from '@solana/web3.js';
export declare const TOKEN_METADATA_DISCRIMINATOR: Buffer;
export interface TokenMetadata {
    updateAuthority?: PublicKey;
    mint: PublicKey;
    name: string;
    symbol: string;
    uri: string;
    additionalMetadata: [string, string][];
}
export declare function pack(meta: TokenMetadata): Uint8Array;
export declare function unpack(buffer: Buffer | Uint8Array): TokenMetadata;
//# sourceMappingURL=state.d.ts.map