import {PublicKey} from './publickey';

export const BPF_LOADER_DEPRECATED_PROGRAM_ID = new PublicKey(
  'BPFLoader1111111111111111111111111111111111',
);
