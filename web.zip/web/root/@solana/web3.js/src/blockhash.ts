/**
 * Blockhash as Base58 string.
 */
export type Blockhash = string;
