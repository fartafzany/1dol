export {default} from 'rpc-websockets/dist/lib/client/websocket.browser';
