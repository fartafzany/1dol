import { Layout } from '@solana/buffer-layout';
export declare const bool: (property?: string | undefined) => Layout<boolean>;
