import { Layout } from '@solana/buffer-layout';
import BigNumber from 'bignumber.js';
export declare const WAD: BigNumber;
export declare const decimal: (property?: string | undefined) => Layout<BigNumber>;
