/// <reference types="node" />
import { PublicKey } from '@solana/web3.js';
export declare const TOKEN_GROUP_SIZE: number;
export interface TokenGroup {
    /** The authority that can sign to update the group */
    updateAuthority?: PublicKey;
    /** The associated mint, used to counter spoofing to be sure that group belongs to a particular mint */
    mint: PublicKey;
    /** The current number of group members */
    size: number;
    /** The maximum number of group members */
    maxSize: number;
}
export declare function packTokenGroup(group: TokenGroup): Uint8Array;
export declare function unpackTokenGroup(buffer: Buffer | Uint8Array): TokenGroup;
//# sourceMappingURL=tokenGroup.d.ts.map