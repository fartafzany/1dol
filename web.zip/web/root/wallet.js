import { Connection, PublicKey, clusterApiUrl, SystemProgram, Transaction } from '@solana/web3.js';
import Wallet from '@project-serum/sol-wallet-adapter';

const providerUrl = 'https://www.sollet.io';
const wallet = new Wallet(providerUrl);

wallet.on('connect', publicKey => {
  console.log('Connected to ' + publicKey.toBase58());
  document.getElementById('connect-wallet').disabled = true;
  document.getElementById('disconnect-wallet').disabled = false;
  document.getElementById('send-transaction').disabled = false;
});

wallet.on('disconnect', () => {
  console.log('Disconnected');
  document.getElementById('connect-wallet').disabled = false;
  document.getElementById('disconnect-wallet').disabled = true;
  document.getElementById('send-transaction').disabled = true;
});

export async function connectWallet() {
  await wallet.connect();
}

export async function disconnectWallet() {
  await wallet.disconnect();
}

export async function sendTransaction() {
  const connection = new Connection(clusterApiUrl('mainnet-beta'));
  const transaction = new Transaction().add(
    SystemProgram.transfer({
      fromPubkey: wallet.publicKey,
      toPubkey: new PublicKey('Bs1xkPyxsk8M44CUr6wg53oPKLBvuDaZF84VQyP217tL'), // Ubah dengan alamat tujuan yang diinginkan
      lamports: 1000000, // Ubah jumlah lamports sesuai kebutuhan
    })
  );
  transaction.feePayer = wallet.publicKey;
  let { blockhash } = await connection.getRecentBlockhash();
