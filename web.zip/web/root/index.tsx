import React from 'react';
import ReactDOM from 'react-dom';
import Connect2Phantom from './connect2phantom';
import Main from './main';

const App = () => (
    <div>
        <Connect2Phantom />
        <Main />
    </div>
);

ReactDOM.render(<App />, document.getElementById('root'));
